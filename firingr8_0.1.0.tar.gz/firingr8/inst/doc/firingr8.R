## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(firingr8)

## ---- eval = FALSE------------------------------------------------------------
#  library(firingr8)
#  
#  process_ephys_csv(csvfile_path = raw_ephys_data, experiment_identifier_path = identifiers_sample, output_path = ".")

## -----------------------------------------------------------------------------
#output in example is "." which is current directory
getwd()

