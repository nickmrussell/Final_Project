## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(firingr8)

## ---- eval = FALSE------------------------------------------------------------
#  library(firingr8)
#  
#  process_ephys_csv(csvfile_path = "https://raw.githubusercontent.com/nickmrussell/Final_Project/main/data/identifiers_sample.csv", experiment_identifier_path = "https://raw.githubusercontent.com/nickmrussell/Final_Project/main/data/identifiers_sample.csv", output_path = ".")
#  
#  list.files()

