## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(firingr8)

## -----------------------------------------------------------------------------
library(firingr8)
input <- raw_ephys_data
indentifiers <- identifiers_sample

## ---- eval = FALSE------------------------------------------------------------
#  process_ephys_csv(input, identifiers, ".")

## -----------------------------------------------------------------------------
#output in example is "." which is present directory
getwd()

