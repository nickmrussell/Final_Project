# Final_Project
## Data Science Collaborative Project
This is the final project for Applied Data Analysis 2024 Course taught by Dr. Anthony Difiore completed by Turner Lime, Nicholas Russell, Daniel San Miguel.
